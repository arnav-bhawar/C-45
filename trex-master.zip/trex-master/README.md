# trex
Offline Game where trex jumps and runs over the obstacles.
